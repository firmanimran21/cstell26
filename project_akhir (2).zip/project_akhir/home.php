 
  <div class="col-12 mt-2">
    <div class="card">
        <div class="card-header">
            Home
        </div>
        <div class="bg">
            <h5 class="card-title">Welcome To NabWater</h5>
            <p class="card-text">NAB Water adalah sebuah perusahaan depot air minum yang menggunakan teknologi Reverse Osmosis (RO)
                untuk menyediakan air minum berkualitas tinggi kepada pelanggan. Dengan menggunakan proses RO, NAB Water mampu menyaring air 
                dari berbagai sumber menjadi air bersih yang bebas dari kontaminan dan partikel-partikel yang tidak diinginkan.</p>
            <a href="#" class="btn btn-primary">Beli Sekarang</a>
        </div>
    </div>
</div>

  <!-- JavaScript untuk Bootstrap -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
<script src="path/to/your/javascript/file.js"></script>
</div>
